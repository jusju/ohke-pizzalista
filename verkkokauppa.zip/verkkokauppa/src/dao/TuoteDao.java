package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import tietokanta.Kysely;
import tietokanta.Yhteys;
import bean.Tuote;
import bean.TuotteenOsa;

/**
 * 
 * @author Jukka Juslin
 * 
 */
public class TuoteDao {

	public ArrayList<Tuote> haeKaikki() {

		ArrayList<Tuote> tuotteet = new ArrayList<Tuote>();
		ArrayList<TuotteenOsa> taytteet = null;
		Connection yhteys = null;

		try {
			// YHTEYDEN AVAUS JA HAKU
			// ajurin lataus
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			// avataan yhteys
			yhteys = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/jusju", "jusju", "feNAO763d");

			// suoritetaan haku
			String sql = "SELECT t.id, t.nimi, t.hinta, GROUP_CONCAT(tuos.id) as content_ids,GROUP_CONCAT(tuos.nimi) as content_names  FROM Tuotteet t, TuotteenOsat tuos, TuoteRivit tr WHERE t.id = tr.tuote_id  AND tuos.id = tr.tuote_id GROUP BY t.id;";
			Statement haku = yhteys.createStatement();
			ResultSet tulokset = haku.executeQuery(sql);

			// k�yd��n hakutulokset l�pi
			while (tulokset.next()) {
				String id = tulokset.getInt("id") + "";
				double hinta = Double.parseDouble(tulokset.getString("hinta"));
				String nimi = tulokset.getString("nimi");

				Tuote pizza = new Tuote();
				pizza.setId(id);
				System.out.println("TuoteDao.haeKaikki()");
				pizza.setHinta(hinta);
				pizza.setNimi(nimi);
				try {
					String taytteetTaulukko = tulokset.getString("content_names");
					if (taytteetTaulukko.contains(",")) {
						taytteet = new ArrayList<TuotteenOsa>();
						String[] taytteetString = tulokset.getString(
								"content_names").split(",");
						for (int j = 0; j < taytteetString.length; j++) {
							taytteet.add(new TuotteenOsa(taytteetString[j]));
						}
					} else {
						taytteet = new ArrayList<TuotteenOsa>();
						taytteet.add(new TuotteenOsa(tulokset
								.getString("content_names")));
					}

				} catch (Exception ex) {

				}

				pizza.setTuotteenOsat(taytteet);
				System.out.println(pizza);
				tuotteet.add(pizza);

			}

		} catch (Exception e) {
			// JOTAIN VIRHETT� TAPAHTUI
			System.out.println("Tietokantahaku aiheutti virheen");
			e.printStackTrace();
		} finally {
			// LOPULTA AINA SULJETAAN YHTEYS
			try {
				if (yhteys != null && !yhteys.isClosed())
					yhteys.close();
			} catch (Exception e) {
				System.out
						.println("Tietokantayhteys ei jostain syyst� suostu menem��n kiinni.");
				e.printStackTrace();
			}
		}

		return tuotteet;
	}
}
