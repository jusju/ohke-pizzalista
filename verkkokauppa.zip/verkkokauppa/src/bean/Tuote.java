package bean;

import java.util.ArrayList;

/**
 * 
 * @author Jukka Juslin
 *
 */
public class Tuote {
	private String id;
	private double hinta;
	private String nimi;
	private ArrayList<TuotteenOsa> tuotteenOsat;

	public Tuote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tuote(String id, double hinta, String nimi,
			ArrayList<TuotteenOsa> tuotteenOsat) {
		super();
		this.id = id;
		this.hinta = hinta;
		this.nimi = nimi;
		this.tuotteenOsat = tuotteenOsat;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getHinta() {
		return hinta;
	}

	public void setHinta(double hinta) {
		this.hinta = hinta;
	}

	public String getNimi() {
		return nimi;
	}

	public void setNimi(String nimi) {
		this.nimi = nimi;
	}

	public ArrayList<TuotteenOsa> getTuotteenOsat() {
		return tuotteenOsat;
	}

	public void setTuotteenOsat(ArrayList<TuotteenOsa> tuotteenOsat) {
		this.tuotteenOsat = tuotteenOsat;
	}

	@Override
	public String toString() {
		return "Tuote [id=" + id + ", hinta=" + hinta + ", nimi=" + nimi
				+ ", tuotteenOsat=" + tuotteenOsat + "]";
	}
}
